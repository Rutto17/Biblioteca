﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;

namespace Biblioteca
{
    [Serializable]
    public partial class Form1 : Form
    {
        object[] fileDaSalvare = new object[5];
        public Utente[] utenti
        {
            get;
            set;
        }
        public Utente utenteCorrente { get; set; }
        public int contaUtenti { get; set; }
        public Admin admin
        {
            get;
            set;
        }
        public LinkedList<Libro> listaLibri=new LinkedList<Libro>();
        public Form1()
        {
            
        InitializeComponent();
            utenteCorrente = new Utente();
            utenti = new Utente[100];
        contaUtenti = 0;
        listaLibri = new LinkedList<Libro>();
          //  Libro daAgg = new Libro("tit"," aut"," casEd", "isb", "s");
            //listaLibri.AddFirst(daAgg);
            admin = new Admin("a", "a");
            if (contaUtenti == 0)
            {
                Form Form4 = new Form4();
                Form4.Show(this);
                MessageBox.Show("Nome e password di default sono 'a','a'");
                this.Visible = false;
            }
        }
        
        private void Button1_Click(object sender, EventArgs e)
        {
            bool ad = false;
            if (textBox1.Text == admin.nome && textBox2.Text == admin.password)
            {
                ad = true;
                Form Form6 = new Form6();
                Form6.Show(this);
                this.Visible = false;
            }
            string emailU = textBox1.Text;
            string passwordU = textBox2.Text;
            bool cèEmail = false;
            bool cèPass = false;
            for (int i = 0;i < contaUtenti; i++)
            {
                if (utenti[i].email == emailU)
                {
                    cèEmail = true;
                }
                if(utenti[i].password == passwordU)
                {
                    cèPass = true;
                }
                if (cèEmail && cèPass == true)
                {
                    utenteCorrente = utenti[i];
                }
                
            }
            if (cèEmail && cèPass == true)
            {
                
                Form Form3 = new Form3();
                Form3.Show(this);
                this.Visible = false;
            }
            else if((cèEmail == false || cèPass == false)&& ad == false)
            {
                 MessageBox.Show("Utente non trovato"); 
            }
            textBox1.Clear();
            textBox2.Clear();
        }

        private void Label2_Click(object sender, EventArgs e)
        {
            Form Form2 = new Form2();
            Form2.Show(this);
            this.Visible = false;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog apri = new OpenFileDialog();
            apri.Filter = "WAO files | *.wao*";
            if (apri.ShowDialog() == DialogResult.OK)
            {
                string s = apri.FileName;
                BinaryFormatter bf = new BinaryFormatter();
                Stream file = File.Open(s, FileMode.OpenOrCreate);
                var dati = (object[])bf.Deserialize(file);
                Utente[] c = (Utente[])dati[0];
                Utente g = (Utente)dati[1];
                int cont = Convert.ToInt32(dati[2]);
                Admin f = (Admin)dati[3];
                LinkedList<Libro> h = (LinkedList<Libro>)dati[4];
                utenti = c;
                utenteCorrente = g;
                contaUtenti = cont;
                admin = f;
                listaLibri = h;

                file.Close();
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog salvaFile = new SaveFileDialog();
            if (salvaFile.ShowDialog() == DialogResult.OK)
            {
                string s = salvaFile.FileName;
                // string s = Directory.GetCurrentDirectory();
                fileDaSalvare[0] = utenti;
                fileDaSalvare[1] = utenteCorrente;
                fileDaSalvare[2] = contaUtenti;
                fileDaSalvare[3] = admin;
                fileDaSalvare[4] = listaLibri;

                Stream file;

                if (File.Exists(s) == true)
                {
                    file = File.Open(s, FileMode.Open);
                }
                else
                {
                    file = File.Create(s + ".wao");
                }

                BinaryFormatter serializzatore = new BinaryFormatter();
                serializzatore.Serialize(file, fileDaSalvare);
                file.Close();
            }
        }
    }
}
