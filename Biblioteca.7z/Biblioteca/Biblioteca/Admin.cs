﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;

namespace Biblioteca
{
    [Serializable]
    public class Admin
    {
        public string nome;
        public string password;

        public Admin(string s1, string s2)
        {
            this.nome = s1;
            this.password = s2;
        }
    }
}
