﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Biblioteca
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string nome = textBox1.Text;
            string password = textBox2.Text;
            (Owner as Form1).admin.nome = nome;
            (Owner as Form1).admin.password = password;
            Owner.Visible = true;
            this.Close();
        }
    }
}
