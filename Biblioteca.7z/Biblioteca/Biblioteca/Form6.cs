﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Biblioteca
{
    public partial class Form6 : Form
    {
        public DataGridView gried { get; set; }
        public Form6()
        {
            InitializeComponent();
        }
        public void StampaLibri(DataGridView tabella, LinkedList<Libro> stampare)
        {
            tabella.Rows.Clear();
            int i = 0;
            foreach (var libro in stampare)
            {
                tabella.Rows.Add();
                tabella.Rows[i].Cells[0].Value = libro.titolo;
                tabella.Rows[i].Cells[1].Value = libro.autore;
                tabella.Rows[i].Cells[2].Value = libro.casaEd;
                tabella.Rows[i].Cells[3].Value = libro.ISBN;
                tabella.Rows[i].Cells[4].Value = libro.datBiblio;
                tabella.Rows[i].Cells[5].Value = libro.disponibile;
                i++;
            }
            tabella.AutoResizeColumns();
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            Owner.Visible = true;
            this.Visible = false;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Form  aggiung = new AggiuntaLibro();
            aggiung.Show(this);
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            if ((Owner as Form1).listaLibri.Count > 0)
            {
                StampaLibri(dataGridView1, (Owner as Form1).listaLibri);
            }
        }

        private void Btn_cerca_Click(object sender, EventArgs e)
        {
            if (txt_parolaChiave.Text == "" && txt_IDChiave.Text == "")
            {
                MessageBox.Show("Inserire tutti i dati necessari");
            }
            else
            {
                Libro cerca = new Libro();
                if (radioButtonTitolo.Checked)
                {
                    cerca.titolo = txt_parolaChiave.Text;
                }
                else if (radioButtonAutore.Checked)
                {
                    cerca.autore = txt_parolaChiave.Text;
                }
                else if (radioButtonEditore.Checked)
                {
                    cerca.casaEd = txt_parolaChiave.Text;
                }
                else if (radioButtonId.Checked)
                {
                    if (txt_IDChiave.TextLength == 0)
                    {
                        MessageBox.Show("Il numero di identificazione deve essere almeno di 1 cifra");
                    }
                    else
                    {
                        cerca.ISBN = txt_IDChiave.Text;
                    }
                }
                LinkedList<Libro> libriCercati = new LinkedList<Libro>();
                LinkedListNode<Libro> appoggio = (Owner as Form1).listaLibri.Last;
                while (appoggio != null)
                {
                    if (appoggio.Value.titolo == cerca.titolo || appoggio.Value.autore == cerca.autore || appoggio.Value.casaEd == cerca.casaEd || appoggio.Value.ISBN == cerca.ISBN)
                    {
                        Libro cercato = new Libro(appoggio.Value.titolo, appoggio.Value.autore, appoggio.Value.casaEd, appoggio.Value.ISBN, appoggio.Value.datBiblio, appoggio.Value.disponibile);
                        libriCercati.AddLast(cercato);
                    }
                    appoggio = appoggio.Previous;
                }
                StampaLibri(dataGridView1, libriCercati);

                txt_parolaChiave.Clear();
                txt_IDChiave.Clear();
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            if ((Owner as Form1).listaLibri.Count <= 0||dataGridView1.Rows.Count == 0) { }
            else
            {
                string s1 = Convert.ToString(dataGridView1.CurrentRow.Cells[0].Value);
                string s2 = Convert.ToString(dataGridView1.CurrentRow.Cells[1].Value);
                string s3 = Convert.ToString(dataGridView1.CurrentRow.Cells[2].Value);
                string s4 = Convert.ToString(dataGridView1.CurrentRow.Cells[3].Value);
                string s5 = Convert.ToString(dataGridView1.CurrentRow.Cells[4].Value);
                string s6 = Convert.ToString(dataGridView1.CurrentRow.Cells[5].Value);
                Libro daEli = new Libro(s1, s2, s3, s4, s5, s6);
                if (daEli.disponibile == "Non disponibile")
                {
                    MessageBox.Show("Libro ancora in prestito");
                }
                else
                {
                    (Owner as Form1).listaLibri.Remove(daEli);
                    dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
                }
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }
    }
}
