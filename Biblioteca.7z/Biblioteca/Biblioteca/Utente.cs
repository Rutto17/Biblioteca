﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;


namespace Biblioteca
{
    [Serializable]
    public class Utente
    {
        public string nome;
        public string cognome;
        public string indirizzo;
        public string email;
        public string telefono;
        public string CodFisc;
        public string password;
        public Libro[] libriInPrestito = new Libro[3];
        public DateTime[,] dataDarestituire = new DateTime[3, 2];
        public int contalibri;

        public Utente()
        {
            this.nome = "";
            this.cognome = "";
            this.indirizzo = "";
            this.email = "";
            this.telefono = "";
            this.CodFisc = "";
            this.password = "";
        }
        public Utente(string s1, string s2, string s3, string s4, string s5, string s6,string s7)
        {
            this.nome = s1;
            this.cognome = s2;
            this.indirizzo = s3;
            this.email = s4;
            this.telefono = s5;
            this.CodFisc = s6;
            this.password = s7;
        }
        public void SetPassword(string z)
        {
            password = z;
        }
        public void PrendoUnLibro(Libro s)
        {
            if (contalibri < 3 )
            {
                libriInPrestito[contalibri] = s;
                dataDarestituire[contalibri, 0] = DateTime.Today;
                dataDarestituire[contalibri, 1] = DateTime.Today.AddDays(60);
                s.disponibile = "Non disponibile";
                contalibri++;

            }
        }
        public void DepositoUnLibro(Libro s,int contatore)
        {
            for(int i = 0; i < contatore; i++)
            {
                if(libriInPrestito[i].Equals(s)== true)
                {
                    libriInPrestito[i].autore = "no no no PTN" ;
                    contalibri--;       
                }
                else
                {

                }
            }
        }

    }
}
