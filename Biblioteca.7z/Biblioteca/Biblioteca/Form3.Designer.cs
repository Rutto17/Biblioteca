﻿namespace Biblioteca
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txt_parolaChiave = new System.Windows.Forms.TextBox();
            this.txt_IDChiave = new System.Windows.Forms.TextBox();
            this.btn_cerca = new System.Windows.Forms.Button();
            this.radioButtonId = new System.Windows.Forms.RadioButton();
            this.radioButtonEditore = new System.Windows.Forms.RadioButton();
            this.radioButtonAutore = new System.Windows.Forms.RadioButton();
            this.radioButtonTitolo = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button3 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(11, 616);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 29);
            this.button1.TabIndex = 16;
            this.button1.Text = "<- Indietro";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // txt_parolaChiave
            // 
            this.txt_parolaChiave.Location = new System.Drawing.Point(13, 247);
            this.txt_parolaChiave.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_parolaChiave.Multiline = true;
            this.txt_parolaChiave.Name = "txt_parolaChiave";
            this.txt_parolaChiave.Size = new System.Drawing.Size(148, 26);
            this.txt_parolaChiave.TabIndex = 47;
            // 
            // txt_IDChiave
            // 
            this.txt_IDChiave.Location = new System.Drawing.Point(13, 247);
            this.txt_IDChiave.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_IDChiave.Name = "txt_IDChiave";
            this.txt_IDChiave.Size = new System.Drawing.Size(148, 26);
            this.txt_IDChiave.TabIndex = 46;
            // 
            // btn_cerca
            // 
            this.btn_cerca.Location = new System.Drawing.Point(13, 283);
            this.btn_cerca.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_cerca.Name = "btn_cerca";
            this.btn_cerca.Size = new System.Drawing.Size(93, 31);
            this.btn_cerca.TabIndex = 45;
            this.btn_cerca.Text = "Ricerca";
            this.btn_cerca.UseVisualStyleBackColor = true;
            this.btn_cerca.Click += new System.EventHandler(this.Btn_cerca_Click);
            // 
            // radioButtonId
            // 
            this.radioButtonId.AutoSize = true;
            this.radioButtonId.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioButtonId.Location = new System.Drawing.Point(13, 179);
            this.radioButtonId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonId.Name = "radioButtonId";
            this.radioButtonId.Size = new System.Drawing.Size(181, 24);
            this.radioButtonId.TabIndex = 43;
            this.radioButtonId.TabStop = true;
            this.radioButtonId.Text = "Numero identificativo";
            this.radioButtonId.UseVisualStyleBackColor = true;
            // 
            // radioButtonEditore
            // 
            this.radioButtonEditore.AutoSize = true;
            this.radioButtonEditore.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioButtonEditore.Location = new System.Drawing.Point(13, 145);
            this.radioButtonEditore.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonEditore.Name = "radioButtonEditore";
            this.radioButtonEditore.Size = new System.Drawing.Size(126, 24);
            this.radioButtonEditore.TabIndex = 44;
            this.radioButtonEditore.TabStop = true;
            this.radioButtonEditore.Text = "Casa editrice";
            this.radioButtonEditore.UseVisualStyleBackColor = true;
            // 
            // radioButtonAutore
            // 
            this.radioButtonAutore.AutoSize = true;
            this.radioButtonAutore.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioButtonAutore.Location = new System.Drawing.Point(13, 111);
            this.radioButtonAutore.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonAutore.Name = "radioButtonAutore";
            this.radioButtonAutore.Size = new System.Drawing.Size(82, 24);
            this.radioButtonAutore.TabIndex = 42;
            this.radioButtonAutore.TabStop = true;
            this.radioButtonAutore.Text = "Autore";
            this.radioButtonAutore.UseVisualStyleBackColor = true;
            // 
            // radioButtonTitolo
            // 
            this.radioButtonTitolo.AutoSize = true;
            this.radioButtonTitolo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioButtonTitolo.Location = new System.Drawing.Point(12, 77);
            this.radioButtonTitolo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonTitolo.Name = "radioButtonTitolo";
            this.radioButtonTitolo.Size = new System.Drawing.Size(72, 24);
            this.radioButtonTitolo.TabIndex = 41;
            this.radioButtonTitolo.TabStop = true;
            this.radioButtonTitolo.Text = "Titolo";
            this.radioButtonTitolo.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(8, 22);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(214, 40);
            this.label7.TabIndex = 40;
            this.label7.Text = "Selezionare per cosa si vuole\r\nricercare:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(13, 208);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(159, 20);
            this.label5.TabIndex = 39;
            this.label5.Text = "Inserire parola chiave";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column6,
            this.Column5});
            this.dataGridView1.Location = new System.Drawing.Point(243, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1219, 584);
            this.dataGridView1.TabIndex = 48;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "Titolo";
            this.Column1.MinimumWidth = 8;
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Autore";
            this.Column2.MinimumWidth = 8;
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "Casa Editrice";
            this.Column3.MinimumWidth = 8;
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.HeaderText = "ISBN";
            this.Column4.MinimumWidth = 8;
            this.Column4.Name = "Column4";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Data";
            this.Column6.MinimumWidth = 8;
            this.Column6.Name = "Column6";
            this.Column6.Width = 150;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.HeaderText = "Stato";
            this.Column5.MinimumWidth = 8;
            this.Column5.Name = "Column5";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(9, 391);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(139, 35);
            this.button2.TabIndex = 49;
            this.button2.Text = "Prendi Libro";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column8,
            this.Column9});
            this.dataGridView2.Location = new System.Drawing.Point(229, 12);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(516, 584);
            this.dataGridView2.TabIndex = 50;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Libri in prestito";
            this.Column7.MinimumWidth = 8;
            this.Column7.Name = "Column7";
            this.Column7.Width = 150;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Data Prestito";
            this.Column8.MinimumWidth = 8;
            this.Column8.Name = "Column8";
            this.Column8.Width = 150;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Da restituire entro il:";
            this.Column9.MinimumWidth = 8;
            this.Column9.Name = "Column9";
            this.Column9.Width = 150;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(9, 473);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(139, 35);
            this.button3.TabIndex = 51;
            this.button3.Text = "Sommario";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(9, 352);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(139, 33);
            this.button8.TabIndex = 52;
            this.button8.Text = "Guarda Libri";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(9, 432);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(139, 35);
            this.button4.TabIndex = 53;
            this.button4.Text = "Restituisci Libro";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.ClientSize = new System.Drawing.Size(1503, 657);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_parolaChiave);
            this.Controls.Add(this.txt_IDChiave);
            this.Controls.Add(this.btn_cerca);
            this.Controls.Add(this.radioButtonId);
            this.Controls.Add(this.radioButtonEditore);
            this.Controls.Add(this.radioButtonAutore);
            this.Controls.Add(this.radioButtonTitolo);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Name = "Form3";
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_parolaChiave;
        private System.Windows.Forms.TextBox txt_IDChiave;
        private System.Windows.Forms.Button btn_cerca;
        private System.Windows.Forms.RadioButton radioButtonId;
        private System.Windows.Forms.RadioButton radioButtonEditore;
        private System.Windows.Forms.RadioButton radioButtonAutore;
        private System.Windows.Forms.RadioButton radioButtonTitolo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.Button button3;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button4;
    }
}