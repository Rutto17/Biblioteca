﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Biblioteca
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Owner.Visible = true;
            this.Visible = false;
        }

        private void Registrati_Click(object sender, EventArgs e)
        {
          /*  if (textBox1.Text == "" || textBox1.Text == "  " ||
                (textBox2.Text == "") ||
                (textBox2.Text == "  ") ||
                textBox1.Text == "\n" || (textBox2.Text == "\n"))
            {
                MessageBox.Show("Riempire tutti i campi!");
            }*/
           
                string nome = textBox1.Text;
                string cognome = textBox2.Text;
                string indirizzo = textBox3.Text;
                string email = textBox4.Text;
                string telefono = textBox5.Text;
                string CodFisc = textBox6.Text;
            string id = "";
            Random random = new Random();
            for (int i = 0; i < 6; i++)
            {
                id += (char)random.Next(97, 122);
            }

            (Owner as Form1).utenti[(Owner as Form1).contaUtenti] = new Utente(nome, cognome, indirizzo, email, telefono, CodFisc,id);
            (Owner as Form1).contaUtenti++;
            label7.Visible = true;
            label8.Visible = true;
            label8.Text = id;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
        }
    }
}
