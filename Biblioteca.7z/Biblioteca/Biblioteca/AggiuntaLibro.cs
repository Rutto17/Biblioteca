﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Biblioteca
{
    public partial class AggiuntaLibro : Form
    {
        public AggiuntaLibro()
        {
            InitializeComponent();
        }

        private void AggiuntaLibro_Load(object sender, EventArgs e)
        {

        }
      
        private void Button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "")|| (textBox2.Text == "") || (textBox3.Text == "") || (textBox4.Text == "")) { MessageBox.Show("Inserire tutti i campi"); }
            else
            {
                string tit = textBox1.Text;
                string aut = textBox2.Text;
                string casEd = textBox3.Text;
                string isb = textBox4.Text;
                string s = Convert.ToString(DateTime.Today);

                Libro daAgg = new Libro(tit, aut, casEd, isb, s, "disponibile");
                //(Owner as Form1).listaLibri.AddFirst(daAgg);
                ((Owner as Form6).Owner as Form1).listaLibri.AddFirst(daAgg);

                this.Close();
            }
        }
    }
}
