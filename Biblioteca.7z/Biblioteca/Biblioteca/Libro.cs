﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;

namespace Biblioteca
{
    [Serializable]
    public class Libro : IEquatable<Libro>, IComparable<Libro>
    {
        public string titolo;
        public string autore;
        public string casaEd;
        public string ISBN;
        public string datBiblio;
        public string disponibile;

        public Libro()
        {
            this.titolo = "";
            this.autore = "";
            this.casaEd = "";
            this.ISBN = "";
            this.datBiblio = "";
            this.disponibile = "";
        }

        public Libro(string titolo, string autore, string casaEditrice, string numeroIdentificativo)
        {
            this.titolo = titolo;
            this.autore = autore;
            this.casaEd = casaEditrice;
            this.ISBN = numeroIdentificativo;
        }

        public Libro(string titolo, string autore, string casaEditrice, string numeroIdentificativo, string data, string disponibile)
        {
            this.titolo = titolo;
            this.autore = autore;
            this.casaEd = casaEditrice;
            this.ISBN = numeroIdentificativo;
            this.datBiblio = data;
            this.disponibile = disponibile;
        }

        public int CompareTo(Libro other)
        {
            throw new NotImplementedException();
        }
        public void NonDisponibile()
        {
            disponibile = "Non disponibile";
        }
        public bool Equals(Libro other)
        {
            if (titolo.CompareTo(other.titolo) == 0 || autore.CompareTo(other.autore) == 0 || casaEd.CompareTo(other.casaEd) == 0 || ISBN.CompareTo(other.ISBN) == 0)
            {
                return true;
            }
            return false;
        }

       /* public void nuovaData(DateTime s)
        {
            storicoDate[contaDate] = Convert.ToString(s);
        }*/

    }
}
